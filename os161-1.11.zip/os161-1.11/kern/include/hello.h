#ifndef _HELLO_H_
#define _HELLO_H_

extern void hello();

#endif

