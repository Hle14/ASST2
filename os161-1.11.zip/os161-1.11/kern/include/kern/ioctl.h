#ifndef _KERN_IOCTL_H_
#define _KERN_IOCTL_H_

/*
 * ioctl operation codes
 */

/* (none yet) */

#endif /* _KERN_IOCTL_H_*/
