//#include <lib.h>

#include <hello.h>

void hello()
{

	kprintf("Hello, World!");

}

