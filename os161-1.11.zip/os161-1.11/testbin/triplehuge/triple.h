void triple(const char *prog);
